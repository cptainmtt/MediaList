var XBMC_GUI = function() {

	// --- Private Variables --- //
	var guiComplete = false;
	var updatingLists = [];
	var setup = null;
	var autoFlipToWall = false;
	var GlobalTokensCounter = 0;
	var loadingTimeoutID, loadingIntervalID;
	//var queuedIDs = [];

	// --- Public Variables --- //
	var self = {
		joins:	{
			firstThumbnail:		1,	// mediaList->S(image)
			firstTitle:			21,	// mediaList->S(text)
			firstYear:			41,	// mediaList->S(text)
			firstWatched:		61,	// mediaList->D(button)
			mediaList:			1,	// L

			diagnostics:		1001,	// D(page)
			media_back_button:	1002,	// D(button)
		},
		XBMC:			null,
	};


	// --- Public Functions --- //
	self.setup = function(params) {

		try {
		self.XBMC = new XBMC_Controller();
		if ( (r = self.XBMC.Setup()) === false ) consolelog("Failed to create the XBMC_Controller object");

		} catch (e) { consolelog("Error running XBMC_Controller.Setup() - " + e) }

		// Clear lists from previous data for new XBMC instance to load new data
		//CF.setJoins([

		//]);

		var watchedJoins = [
			"d"+self.XBMC.joins.connected.join,
			"d"+self.joins.mediaList,
			"l"+self.joins.mediaList,
			"s"+self.joins.mediaList,
			CF.GlobalTokensJoin,
		];
		for (i = 1; i <= 8; i++) watchedJoins.push("l"+self.joins.mediaList + "::d" + i);

		CF.watch(CF.FeedbackMatchedEvent, "XBMC", "JSON Response", onJSONResponse);
		CF.watch(CF.JoinChangeEvent, watchedJoins, onJoinChange);

		CF.watch(CF.ConnectionStatusChangeEvent, "XBMC", onConnectionChange, true);

		setMediaListTitle(); // set to default
		CF.listRemove("l"+self.joins.mediaList); // doesnt trigger list join change event
		onJoinChange("l"+self.joins.mediaList, null, null); // manually trigger list join change event to start interval

		return r;
	};

	/*
	// Get media type from arguments provided as either tokens or a string
	// NOT CURRENTLY: Prioritise tokens over string
	*/
	self.requestMedia = function() {
		var tokens = {}, params = {};
		var cases = {
			string: function(arg) {
				// check if passed type string if the type hasnt already been set
				//consolelog("string case: pre check params.type = " + params.type);
				if (!params.type) params.type = self.XBMC.checkMediaType(arg, false); // don't return default type
				//consolelog("string case: post check params.type = " + params.type);
			},
			object: function(obj) { tokens = obj },
		};
		try {
		for ( var i = 0; i < arguments.length; i++ ) (cases[typeof arguments[i]]) ? cases[typeof arguments[i]](arguments[i]) : ""; // read arguments
		} catch (e) {
			consolelog("requestMedia(): exception caught in argument loop - " + e);
		}
		consolelog("\n\nrequestMedia(): arguments = --v, params = ----v, tokens = ------v");
		console.log(arguments);
		//console.log(params);
		console.log(tokens);

		if ( tokens["[file]"] ) {
			// play file
			self.XBMC.PlayToken(tokens);
			// use fanart token to set bg? or set in now playing loop... delete token from buildMediaList if not in use
		} else {
			//set media page join = 1 // * (4)
			consolelog("requestMedia(): setting mediaList join = 1");
			CF.setJoin("d"+self.joins.mediaList, 1);
			// get media type and id of media type to load if not passed by string already
			if ( !params.type ) {
				consolelog("requestMedia(): setting params from tokens");
				params = { type: tokens["[type]"], id: tokens["[id]"] };
			}
			consolelog("requestMedia(): Found: params.type = " + params.type + ", id = " + params.id);

			// set the tokens for the back button
			consolelog("Setting the back button tokens");
			if (tokens["[back]"]) CF.setToken("d"+self.joins.media_back_button, "[back]", tokens["[back]"]);
			console.log(tokens);

			consolelog("requestMedia(): self.XBMC.currentList.type != (params.type = self.XBMC.checkMediaType(" + params.type + ", false)) = " + (self.XBMC.currentList.type != (params.type = self.XBMC.checkMediaType(params.type, false))));
			consolelog("requestMedia(): " + self.XBMC.currentList.type + " != (" + params.type + " = self.XBMC.checkMediaType(" + params.type + ", false)) = " + (self.XBMC.currentList.type != (params.type = self.XBMC.checkMediaType(params.type, false))));
			// check if media list needs updating
			if (self.XBMC.currentList.type != (params.type = self.XBMC.checkMediaType(params.type, false)) ) {
				//clear the media list - triggers join change event to show loading elements
				console.log("requestMedia(): clearing the media list")
				CF.listRemove("l"+self.joins.mediaList);

				//set media page title join and token id, set value to trigger join change event
				setMediaListTitle({"type": params.type, "id": params.id});

				//consolelog("requestMedia(): updating the GlobalTokens - should fire on change event");
				//CF.setJoins([{join: CF.GlobalTokensJoin, value: GlobalTokensCounter++, tokens: params } ]);

				// load media info from XBMC (if req'd) --> moved to media title join change event
				//consolelog("Starting self.loadMediaList(" + params + " from requestMedia()");
				//console.log(params);
				//self.loadMediaList(params);
			} else {
				// change the list!!
			}
		}
	};

	/*
	// Accepts arguments - type as string, force as boolean || object { type as string, force as boolean }
	//
	*/
	self.loadMediaList = function() {
		consolelog("loadMediaList() called with following arguments --v");
		console.log(arguments);
		var params = {};
		var cases = {
			object:		function(obj) { if ( self.XBMC.checkMediaType(obj.type, false) ) params = obj },
			string:		function(str) { if ( !params.type ) params["type"] = self.XBMC.checkMediaType(str, false) },
			boolean:	function(bool) { if ( typeof params.force != "boolean" ) params["force"] = bool },
		};

		//loop through supplied arguments
		try {
		for( var i = 0; i < arguments.length; i++ ) cases[typeof arguments[i]](arguments[i]);
		} catch (e) {
			consolelog("loadMediaList(): exception caught in argument loop");
		}

		//console.log(params);
		if (params.force) delete self.XBMC.mediaList[params.type];

		//if (params.type && (!self.XBMC.mediaList[params.type] || params.force)) { // OLD VERSION - now deleting mediaList is force above
		// CHECK: if the list gets re-loaded when the mediaList is defined. i think it may be... might need to add a check typeof MediaList[type] && params.force
		// should not be re-loaded is mediaList[type] is non-empty
		consolelog("Checking if mediaList[" + params.type + "] has already been loaded --v. params should not be added to updatingLists if so.");
		console.log(self.XBMC.mediaList[params.type]);
		consolelog("Boolean check of mediaList[" + params.type + "] = " + !!self.XBMC.mediaList[params.type]);
		if (params.type && !self.XBMC.mediaList[params.type]) {
			//consolelog("loadMediaList(): mediaList[type] = --v");
			//console.log(self.XBMC.mediaList[params.type]);

			consolelog("checking if params.type is valid to add to updatingLists");
			// mediaList[type] needs loading are is being forced to reload
			//if (params.force) CF.listRemove("l"+self.joins.mediaList); // triggers join change event to show loading graphics WRONG! force does not mean show the list

			try {
				var updatingLists = updatingLists || {};
				// string test
				console.log(updatingLists);
				updatingLists[found = self.XBMC.checkMediaType(params.type, false)] = true; //params.force || false;
				consolelog("loadMediaList(): found " + found + " as string. adding " + found + " to updatingLists{}");
			} catch (e) {
				try {
					// array test
					while(prop = params.type.shift()) updatingLists[self.XBMC.checkMediaType(prop, false)] = true; //params.force || false;
					consolelog("passed array test - " + e);
				} catch (e) {
					try {
						// object test
						for (var prop in params.type) {
							if( params.type.hasOwnProperty(prop) && (type = self.XBMC.checkMediaType(prop, false)) ) updatingLists[type] = true; //params.force || false;
						}
						consolelog("passed object test - " + e);
					} catch (e) {
						consolelog("Failed to find valid type in param argument");
					}
				}
			}
		} else consolelog("loadMediaList(): no arguments passed - proceed to updatingList[] queue");


		// check if updatingList has more items to load OR if the current mediaList is empty
		// DO I NEED TO CHECK IF XBMC IS CONNECTED OR JUST ADD TO JSON QUEUE? YES
		// If add to json queue (dont check connected), need to remove updating list  once json completed otherwise its like to run again when loadMediaList is called on connection
		// OR dont call loadMediaList on connection....
		// depends when you want to remove updatingLists... probably once response received from XBMC... -> so check connected before sending!!

		//if (updatingLists[Object.keys(updatingLists)[0]] || !self.XBMC.mediaList[Object.keys(updatingLists)[0]] ) {
		// shouldnt need to check if mediaList is empty... loadMediaList should be called straight after mediaList[type] is deleted...CHECK THIS IS CORRECT!

		try {
			//if ( updatingLists[Object.keys(updatingLists)[0]] && self.XBMC.joins.connected.value ) {
			if ( self.XBMC.joins.connected.value ) {
				self.XBMC.Get[Object.keys(updatingLists)[0]]();
				consolelog("loadMediaList(): queueing json command to get \"" + Object.keys(updatingLists)[0] + "\" list from XBMC...");
			}
		} catch (e) {
			// check runs now that have added delete updatingLists as no exception is thrown when updatingLists is undefined :( only when it is not declared(deleted)...
			consolelog("Finished loading media lists from XBMC...\nException caught: (" + e + ")")
			//QueueInitMsg("finishing loading media lists from xbmc...");
		}

	};

	buildMediaList = function(json) {

		type = self.XBMC.checkMediaType(json.id, false);
		consolelog("buildMediaList(): type = " + type);

		if (type && !json.hasOwnProperty("error")) {
			//json = self.XBMC.mediaList[type];
			var itemCount = 0;
			var rowCount = 0;
			var list = [];
			var rowItems = {};
			var maxPerRow = 8;
			//var tokens = {};
			var back = {}, id, major, minor, thumbnail, fanart, playcount, file, resume, itemtype;

			var cases = {};

			var movies = function(i) {
				try {
					// "thumbnail", "fanart", "genre", "playcount", "mpaa", "rating", "runtime", "year", "file", "resume"
					id		= json.result.movies[i].movieid;
					resume		= json.result.movies[i].resume;
					file		= json.result.movies[i].file;
					fanart		= json.result.movies[i].fanart;
					thumbnail	= json.result.movies[i].thumbnail;
					major		= json.result.movies[i].label;
					minor		= json.result.movies[i].year;
					//loadtype	= "movie";
					playcount	= (json.result.movies[i].playcount > 0) ? 1 : 0;
				} catch (e) {
					consolelog("buildMediaList(): Exception caught creating a movie item");
				}
			};

			var tvshows = function() {
				try {
					// result["thumbnail", "fanart", "title|label", "year", "episode", "art.fanart|poster", "file", "playcount", "watchedepisodes"]
					tvshowid = json.result.tvshows[i].tvshowid;

					//consolelog("Queueing seasons for tvshowid(" + tvshowid + ") to be loaded ...");
					if ( typeof self.XBMC.queuedIDs["seasons"] != "object" ) self.XBMC.queuedIDs["seasons"] = [];
					self.XBMC.queuedIDs["seasons"].push({"tvshowid": tvshowid});

					// set reference variables
					//consolelog("typeof self.XBMC.ref.tvshows = " + typeof self.XBMC.ref.tvshows);
					if (typeof self.XBMC.ref.tvshows == "undefined") self.XBMC.ref.tvshows = {};
					try {
						self.XBMC.ref.tvshows[tvshowid] = {"index": rowCount, "item": itemCount + 1};
					} catch (e) {
						consolelog("FAILED TO SET TV SHOWS REFERENCE VARIABLE");
					}
					fanart		= json.result.tvshows[i].fanart;
					id			= json.result.tvshows[i].tvshowid;
					thumbnail	= json.result.tvshows[i].thumbnail;
					major		= json.result.tvshows[i].title;
					minor		= json.result.tvshows[i].year;
					loadtype	= "seasons";
					playcount	= (json.result.tvshows[i].watchedepisodes == json.result.tvshows[i].episode) ? 1 : 0;
					//back = {type: type, id: };
				} catch (e) {
					consolelog("Failed to load a tv show - " + e);
				}
			};

			var seasons = function(i) {
				try {
					console.log(json.result);
					// "season", "tvshowid", "showtitle", "year", "playcount", "episode", "thumbnail", "file", "art", "watchedepisodes"
					// check to make sure there is at least one season available for tvshowid
					if (json.result.seasons[i].hasOwnProperty("tvshowid")) {
						var tvshowid = json.result.seasons[i].tvshowid;
						var season = json.result.seasons[i].season;

						consolelog("Queueing episodes in season(" + season + ") for tvshowid(" + tvshowid + ") to be loaded ...");
						if ( typeof self.XBMC.queuedIDs["episodes"] != "object" ) self.XBMC.queuedIDs["episodes"] = [];
						self.XBMC.queuedIDs["episodes"].push({"tvshowid": tvshowid, "season": season});
						//console.log(self.XBMC.queuedIDs["episodes"]);

						// set reference variables
						consolelog("typeof self.XBMC.ref.tvshows[" + tvshowid + "] = " + typeof self.XBMC.ref.tvshows[tvshowid]);
						consolelog("typeof self.XBMC.ref.tvshows[" + tvshowid + "][" + season + "] = " + typeof self.XBMC.ref.tvshows[tvshowid][season]);

						if (typeof self.XBMC.ref.tvshows[tvshowid][season] == "undefined") self.XBMC.ref.tvshows[tvshowid][season] = {};
						self.XBMC.ref.tvshows[tvshowid][season] = {"index": rowCount, "item": itemCount + 1};

						consolelog("typeof self.XBMC.ref.tvshows[" + tvshowid + "][" + season + "] = " + typeof self.XBMC.ref.tvshows[tvshowid][season]);

						consolelog("typeof self.XBMC.mediaList.tvshows[" + self.XBMC.ref.tvshows[tvshowid].index + "][\"seasons\"" + self.XBMC.ref.tvshows[tvshowid].item + "] = " + typeof self.XBMC.mediaList.tvshows[ self.XBMC.ref.tvshows[tvshowid].index ]["seasons" + self.XBMC.ref.tvshows[tvshowid].item]);
						if ( typeof self.XBMC.mediaList.tvshows[ self.XBMC.ref.tvshows[tvshowid].index ]["seasons" + self.XBMC.ref.tvshows[tvshowid].item] == "object" ) {
							// add season info...
							//var leveloneid = tvshowid;
							fanart		= json.result.seasons[i].art.fanart;
							thumbnail	= json.result.seasons[i].art.poster;
							id			= season;
							major		= json.result.seasons[i].title;
							minor		= json.result.seasons[i].year;
							playcount	= (json.result.seasons[i].watchedepisodes == json.result.seasons[i].episode) ? 1 : 0;
							loadtype	= "episodes";
							back		= {type: "tvshows", id: tvshowid};
						}
					}
				} catch (e) {
					consolelog("Failed to load a tv show season. The tvshowid(" + tvshowid + ") doesnt exist - " + e);
				}
			};

			var episodes = function(i) {
				try {
					// "episode", "season", "tvshowid", "showtitle", "resume", "title", "year", "playcount", "thumbnail", "file", "art.posert|fanart", "watchedepisodes"
					var tvshowid = json.result.episodes[i].tvshowid;
					var season = json.result.episodes[i].season;

					consolelog("self.XBMC.mediaList[\"tvshows\"][" + self.XBMC.ref["tvshows"][tvshowid].index + "][\"seasons\"" + self.XBMC.ref["tvshows"][tvshowid].item + "][" + self.XBMC.ref["tvshows"][tvshowid][season].index + "][\"episodes\"" + self.XBMC.ref["tvshows"][tvshowid][season].item + "]");
					if ( typeof self.XBMC.mediaList["tvshows"][self.XBMC.ref["tvshows"][tvshowid].index]["seasons" + self.XBMC.ref["tvshows"][tvshowid].item][self.XBMC.ref["tvshows"][tvshowid][season].index]["episodes" + self.XBMC.ref["tvshows"][tvshowid][season].item] == "object") {
						// add episode info...
						file		= json.result.episodes[i].file;
						fanart	 	= json.result.episodes[i].art.fanart;
						id			= json.result.episodes[i].uniueid;
						resume		= json.result.episodes[i].resume;
						thumbnail	= json.result.episodes[i].art.poster;
						major		= json.result.episodes[i].title;
						minor		= "S" + json.result.episodes[i].season + ":E" + json.result.episodes[i].episode;
						playcount	= (json.result.episodes[i].watchedepisodes == json.result.episodes[i].playcount) ? 1 : 0;
						//loadtype	= "episode";
						back		= {type: "seasons", id: season};
						//var leveloneid = tvshowid;
						//var leveltwoid = season;
					}
				} catch (e) {
					consolelog("Failed to load a tv show episode. The episode in season(" + season + ") of tvshowid(" + tvshowid + ") don't exist? - " + e);
				}
			};

			var artists = function(i) {
				try {
					console.log(json.result.artists[i]);
					// "artist", "artistid", "thumbnail", "fanart", "formed", "label"
					artistid = json.result.artists[i].artistid;
					consolelog("Queueing albums for artist(" + artistid + ") to be loaded ...");
					if ( typeof self.XBMC.queuedIDs["albums"] != "object" ) self.XBMC.queuedIDs["albums"] = [];
					self.XBMC.queuedIDs["albums"].push({"artistid": artistid});
					//console.log(self.XBMC.queuedIDs["albums"]);

					// set reference variables
					if (typeof self.XBMC.ref["artists"][artistid] == "undefined") self.XBMC.ref["artists"][artistid] = [];
					self.XBMC.ref["artists"][artistid] = {"index": rowCount, "item": itemCount + 1};

					fanart		= json.result.artists[i].fanart;
					id			= json.result.artists[i].artistid;
					thumbnail	= json.result.artists[i].thumbnail;
					major		= json.result.artists[i].artist;
					minor		= json.result.artists[i].formed;
					loadtype	= "albums";
				} catch (e) {
					consolelog("Failed to load an artist - " + e);
				}
			};

			var albums = function(i) {
				try {
					// "artistid", "albumartistid", "albumid", "thumbnail", "title", "fanart", "year", "playcount"
					var artistid = json.result.albums[i].artistid;
					var albumid = json.result.albums[i].albumid;

					consolelog("Queueing songs on albumid(" + albumid + ") for artistid(" + artistid + ") to be loaded ...");
					if ( typeof self.XBMC.queuedIDs["songs"] != "object" ) self.XBMC.queuedIDs["songs"] = [];
					self.XBMC.queuedIDs["songs"].push({"artistid": artistid, "albumid": albumid});
					//console.log(self.XBMC.queuedIDs["songs"]);

					// set reference variables
					if (typeof self.XBMC.ref["artists"][artistid][albumid] == "undefined") self.XBMC.ref["artists"][artistid] = [];
					self.XBMC.ref["artists"][artistid][albumid] = {"index": rowCount, "item": itemCount + 1};

					if ( typeof self.XBMC.mediaList["artists"][ self.XBMC.ref.artists[artistid].index ]["albums" + self.XBMC.ref.artists[artistid].item] == "object" ) {
						//var leveloneid	= artistid;
						fanart		= json.result.albums[i].fanart;
						id			= albumid;
						thumbnail	= json.result.albums[i].thumbnail;
						major		= json.result.albums[i].title;
						minor		= json.result.albums[i].year;
						playcount	= json.result.albums[i].playcount;
						loadtype	= "songs";
						back		= {type: "artists", id: artistid};
					}
				} catch (e) {
					consolelog("Failed to load an album. The artistid(" + artistid + ") doesnt exist? - " + e);
				}
			};

			var songs = function(i) {
				try {
					// "thumbnail", "fanart", "title", "track", "file", "albumartistid", "albumid", "songid", "playcount", "album"
					var artistid = json.result.songs[i].artistid;
					var albumid = json.result.songs[i].albumid;

					consolelog("self.XBMC.mediaList[\"artists\"][" + self.XBMC.ref.artists[artistid].index + "][\"albums\"" + self.XBMC.ref.artists[artistid].item + "][" + self.XBMC.ref.artists[artistid][albumid].index + "][\"songs\"" + self.XBMC.ref.artists[artistid][albumid].item + "]");
					if ( typeof self.XBMC.mediaList["artists"][self.XBMC.ref.artists[artistid].index]["albums" + self.XBMC.ref.artists[artistid].item][self.XBMC.ref.artists[artistid][albumid].index]["songs" + self.XBMC.ref.artists[artistid][albumid].item] == "object") {
						// add song info...

						//var leveloneid = artistid;
						//var leveltwoid = albumid;
						fanart		= json.result.songs[i].fanart;
						id			= songid;
						file		= file;
						thumbnail	= json.result.songs[i].thumbnail;
						major		= json.result.songs[i].track + ". " +json.result.songs[i].title;
						minor		= json.result.songs[i].album;
						playcount	= json.result.songs[i].playcount;
						//loadtype	= "song";
						back		= {type: "albums", id: albumid};
					}
				} catch (e) {
					consolelog("Failed to load a tv show episode list. The songs on season(" + season + ") of tvshowid(" + tvshowid + ") don't exist - " + e);
				}
			};

			addThumbnail = function(fake) {
				// fake == false => add a empty/hidden thumbnail
				var tokens = {};
				if (!fake) {
					if ( fanart ) {
						tokens["[fanart]"] = cleanImage(fanart);
						// CF.loadAsset(tokens["[fanart]"], CF.UTF8); // reeeeeeally doesnt like this :-!
					}
					if ( file )		tokens["[file]"]	= decode_utf8(file);
					if ( resume )	tokens["[resume]"]	= resume;
					if ( loadtype )	tokens["[type]"]	= loadtype;
					if ( id )		tokens["[id]"]	= id;
					//tokens["[type]"] = type.slice(0, -1);
					if ( back )		tokens["[back]"]	= JSON.stringify( back );
					//tokens["[type]"] = type;
				}

				rowItems["d"+(self.joins.firstWatched+itemCount)]	= (!fake) ? ((playcount > 0) ? 1 : 0) : "";
				rowItems["s"+(self.joins.firstTitle+itemCount)]		= (!fake) ? decode_utf8(major) : "";
				rowItems["s"+(self.joins.firstYear+itemCount)]		= (!fake) ? (decode_utf8((typeof minor == "number") ? minor.toString() : minor)) : "";
				rowItems["s"+(self.joins.firstThumbnail+itemCount)]	= (!fake) ? cleanImage(thumbnail) : "";
				rowItems["d"+(self.joins.firstThumbnail+itemCount)]	= { // button for selecting item
					"value": 0,
					"tokens": tokens
				};

				itemCount++;
			};

			var padRow = function() {
				// only pad if the row isnt empty
				if (itemCount < maxPerRow && rowItems.length > 0 ) {
					// hide/clear remaining items in row
					while (itemCount < maxPerRow) addThumbnail(false); // empty thumbnail

					// add last row to array
					list.push(rowItems);
				}
			};


			// create the cases object to call the req'd functions
			//for (var i = 0; i < self.XBMC.mediaListTypes.length; i++) cases[self.XBMC.mediaListTypes[i]] = self.XBMC.mediaListTypes[i]; // case["movies"] = movies();
			var cases = {
				movies: 	movies,
				tvshows:	tvshows,
				season:		seasons,
				episodes: 	episodes,
				artists:	artists,
				albums:		albums,
				songs:		songs
			};

			//consolelog("cases = --v");
			//console.log(cases);

			try {
				// create the list by looping thru the json response object
				for (var i = 0; i < json.result.limits.total; i++) {
					if (itemCount == maxPerRow) {
						itemCount = 0;
						rowCount++;

						list.push(rowItems);

						rowItems = {}; // reset horizontal row list
					}

					if (cases[type]){
						cases[type](i);		// build the thumbnail
						addThumbnail();		// add the thumbnail to the row
					}
				}
			} catch (e) {
				consolelog("buildMediaList(): Exception caught in json.result for loop... - " + e);

			}

			padRow(); // clean up last row (hide empty thumbnails)

			consolelog("Finished creating list for " + type);
			//self.XBMC.mediaList[type] = list; // set here or in GT join change event??  join change event
			//consolelog("WHAT THE mediaList[currentList] SHOULD LOOK LIKE!! --v");
			//console.log(list);


			// !! DONT ADD TO LIST HERE - THIS JUST BUILDS IT AND ADD'S TO GT... INTERVAL WATCHING mediaList[type] ADD'S THE LIST !!
			//CF.listRemove("l"+self.joins.mediaList); // double check list is empty to avoid duplicating
			//CF.listAdd("l"+self.joins.mediaList, list); //add array to iviewer liste=

			// NEED TO HAVE LIST TITLE SET BEFORE HERE

			// set mediaList global token [type]
			var gtok = {};
			gtok["[" + type + "]"] = JSON.stringify(list); // stupid square brackets :-P
			//consolelog("What the mediaList[currentList] DOES look like (stringified)!! --v");
			//console.log(gtok);
			CF.setJoins([
				// triggers join change event to update mediaList[type]? hopefully AFTER the current list GT is changed... :-!
				{ join: CF.GlobalTokensJoin, value: GlobalTokensCounter++, tokens: gtok }
			]);

			// clean up variables
			delete list;
		}

		consolelog("buildMediaList(): Deleting updatingLists[" + type + "] - check doesnt throw exception if not defined, ie: type = false");
		delete updatingLists[type];  // delete the media type from the queue of lists to be loaded

		try {

			Object.keys(updatingLists).length || delete updatingLists; 					// NEEDS TESTING!!!
			consolelog("buildMediaList() - TESTING: Object.keys(updatingLists).length || delete updatingLists - hopefully no exception is thrown. Remove this log if this msg is shown...");

			consolelog("buildMediaList() is requesting to load next media list in queue");
			self.loadMediaList(); // cycles through updatingLists until empty

			//consolelog("No more media lists need loading... deleting updatingLists...")
		} catch (e) {
			// does this ever get called??
			consolelog("WOW!! Exception caught at the end of buildMediaList() whilst removing or deleting updatingLists after creating a " + type + " list. May need to move self.loadMediaList() to catch block..?");
		}
	};



	// --- Private Functions --- //

	function onJSONResponse(feedbackItem, matchedString) {
		//consolelog("json feeback received...\n " + matchedString);
		for (i = 0; i < matchedString.length; i++) {
			Switch1:
			switch (matchedString[i]){
				case "{":
					self.XBMC.jsonBraceCount++;
					valid = true;
					break Switch1;
				case "}":
					self.XBMC.jsonBraceCount--;
					break Switch1;
			}

			if (valid == true) self.XBMC.jsonBuffer += matchedString[i]; // add character to buffer

			if (valid != undefined && self.XBMC.jsonBraceCount == 0) {
				// complete JSON response - should parse correctly
				//consolelog("Found completed JSON response -> " + self.XBMC.jsonBuffer + "");
				try {
					var decoded = JSON.parse(self.XBMC.jsonBuffer);
					consolelog("Decoded json feedback = <see next line>");
					console.log(decoded);
					if (decoded.hasOwnProperty("error")) consolelog("Error in JSON response - " + decoded.error.message + ((decoded.error.hasOwnProperty("data")) ? ("\nMethod: " + decoded.error.data.method + "\nMessage: " + decoded.error.data.stack.message) : ""));
					else if (decoded === null) consolelog("Failed to parse JSON string :(");
				} catch (e) {
					consolelog("There was a problem parsing a received JSON command. It has been discarded. (decoded = " + decoded + ")\n - " + e);
				} finally {
					if (decoded) jsonCallback(decoded); // send to json callback function
					// now reset buffer and and start again...
					valid = undefined;
					delete valid;
					self.XBMC.jsonBuffer = "";
					self.XBMC.jsonBraceCount = 0;
					self.XBMC.jsonWaitResponse = false;
				}

			}
		}
	}


	function jsonCallback(json) {
		// use the decoded data here
		//CFlogObject(json);
		//console.log(json);

		//consolelog("JSON Response from id = '" + json.id + "', method = '" + json.method + "' ->\n" + JSON.stringify(json));

		// Perform REGEX to find response type (movies, video, audio, etc) - TODO!!
		consolelog("XBMC Feedback JSON id = " + json.id);

		//if ( !json.hasOwnProperty("id") ) json.id = null;
		//if(json.hasOwnProperty("error")) console.log("Error received in JSON response... shouldnt have made it this far!!");
		//else {
		switch ( (json.hasOwnProperty("id") ? json.id : null) ) {
			case self.XBMC.ids.movies:
			case self.XBMC.ids.tvshows:
			case self.XBMC.ids.artists:
			case self.XBMC.ids.seasons:
			case self.XBMC.ids.albums:
				//self.XBMC.mediaList[self.XBMC.checkMediaType(json.id, false)] = json;

				buildMediaList(json);
				//type = self.XBMC.checkMediaType(json.id, false)
				//if (type) {
					//mediaList[type] = json; // kills loading interval as interval exits once mediaList[type] != undefined
					//buildMediaList(json); // why set json twice...??
				//}
				break;
			case self.XBMC.ids.seasons:
			case self.XBMC.ids.albums:
				// 2nd level operation
				if (type = self.XBMC.checkMediaType(json.id)) {
					if (self.XBMC.queuedIDs.hasOwnProperty(type) && self.XBMC.queuedIDs[type].length > 0) {

					} else{

					}
				}
				break;
			case self.XBMC.ids.episodes:
			case self.XBMC.ids.songs:
				// 3rd level operation


				break;
			case self.joins.mediaList:
				//self.XBMC.buildMovies(self.joinMovies, json);
				// Update the wall list
				break;
			case undefined:
				// XBMC sent JSON response without request
				console.log(json);
				break;
			default:
				console.log(json);
				if ( json.hasOwnProperty("result") ) {
					consolelog("json.result = " + json.result);
					switch(json.result) {
						case "pong":
							// not needed if using connected join?
							CFlog("Ping response received");
							CF.setJoin("d"+self.XBMC.joins.connected.join, 1); // force connected join update
							break;
						default:
							//console.log(json);
							consolelog("typeof result.hasOwnProperty = " + (typeof json.result.hasOwnProperty));
							CFlog("Nothing required from JSON response in jsonCallback()");
					}
				}
		}
		//}
	}


	function onJoinChange(join, value, tokens) {
		consolelog("onJoinChange(" + join + ", " + value + ", " + tokens + ")");
		switch (join) {
			case "d"+self.XBMC.joins.connected.join:
				self.XBMC.joins.connected.value = value;
				if (value == 1) {
					consolelog("XBMC is connected!");
					if ( self.XBMC.jsonQueue.length > 0 ) self.XBMC.json(); // re trigger the json queue loop
					if (!self.XBMC.mediaList[self.XBMC.currentList.type]) {
						consolelog("Connected join change event is requesting loadMediaList(currentList)");
						self.loadMediaList(self.XBMC.currentList);  // re-loads list from XBMC
					}
				}
				break;
			case CF.GlobalTokensJoin:
				//CF.getJoin(CF.GlobalTokensJoin, function(j, v, t) {
					console.log(tokens);
					try {
						var prevList = JSON.parse(tokens["[currentList]"]);

						self.XBMC.currentList = JSON.parse(tokens["[currentList]"]);
						consolelog("GT JoinChangeEvent: loaded local currentList from GT = --v");
						console.log(self.XBMC.currentList);
					} catch (e) {
						consolelog("The [currentList] global token was not retrieved - " + e);
					}

					// update the local mediaList arrays
					["artists", "movies", "tvshows"].forEach(function(value, index) {
						try {
							self.XBMC.mediaList[self.XBMC.currentList.type] = JSON.parse(tokens["[" + self.XBMC.currentList.type + "]"]);
							consolelog("GT JoinChangeEvent: mediaList[currentList] loaded from GT");
							//consolelog("GT JoinChangeEvent: loaded mediaList = --v");
							//console.log(self.XBMC.mediaList[self.XBMC.currentList.type]);
						} catch (e) {
							consolelog("The [" + index + "] global token was not retrieved - " + e);
						}
					}

					// lists not being reloaded if mediaList[currentList] exists...
					CF.listInfo("l"+self.joins.mediaList, function(list, items) {
						// add array to list if
						// 1. the list is empty
						// 2. the previous list is different to the current list (may need CF.listRemove...
						consolelog("currentList.type != prevsList.type = " + (self.XBMC.currentList.type != prevList.type) + ", items = " + items + ", !items = " + !items);
						if ( (self.XBMC.currentList.type != prevList.type || !items) && self.XBMC.mediaList[self.XBMC.currentList.type]){

							if (items) CF.listRemove(list); // clear the list if not already done
							// update the list - CHECK TIMING
							// OPTION #1: remove list here - need to set currentList(set from title change event) ASAP when changing lists
							// OPTION #2: add list here and use list join change to kill loading loop :))) !!! list must be remove before media list title set....
							// OPTION #2 currently in use

							CF.listAdd("l"+self.joins.mediaList, self.XBMC.mediaList[self.XBMC.currentList.type]);
						}
					});
					CF.setJoin("d"+self.joins.media_back_button, (["movies", "tvshows", "artists"].indexOf(self.XBMC.currentList.type) == -1) ? 1 : 0);
				//});

				break;
			case "d"+self.joins.mediaList:
				CF.setJoin("d"+self.joins.diagnostics, (value) ? 0 : 1);
				break;
			case "s"+self.joins.mediaList:
				// save currentList
				consolelog("Media list title JoinChangeEvent is saving the [currentList] Global Token");
				CF.setJoins([
					{join: CF.GlobalTokensJoin, value: GlobalTokensCounter++, tokens: { "[currentList]": JSON.stringify({type: tokens["type"], id: tokens["id"]}) }},
				]);
				consolelog("Starting self.loadMediaList(" + tokens["type"] + ") from the media list title JoinChangeEvent");
				self.loadMediaList(tokens["type"]);
				break;
			case "l"+self.joins.mediaList:
				// media list changed

				CF.listInfo(join, function(list, count) {
					consolelog("JoinChangeEvent(l1): media list (" + join + ") has " + count + " items in it");
					if (count == 0) {
						consolelog("JoinChangeEvent(l1): The media list has been cleared (not by me!). I Will start the loading timeout and interval...");
						/*
						var graphics = [
							{ join: "s"+self.joins.media_loading_base,	opacity: 0},
							{ join: "d"+self.joins.media_loading_progress,	opacity: 0},
							{ join: "s"+self.joins.media_loading_text,	opacity: 0},
							{ join: "s"+self.joins.media_loading_dotone,	opacity: 0},
							{ join: "s"+self.joins.media_loading_dottwo,	opacity: 0},
							{ join: "s"+self.joins.media_loading_dotthree,	opacity: 0},
						];
						*/
						// check timer not already started and the the media list being viewed is empty
						if (!loadingTimeoutID && !self.XBMC.mediaList[self.XBMC.currentList]) {
							// start loading timeout and interval
							loadingTimeoutID = setTimeout(function() {
								// clear the loading interval
								//clearInterval(loadingIntervalID);
								//delete loadingIntervalID;
								delete loadingTimeoutID;
								// hide the loading graphics
								//for ( i = 0; i < graphics.length; i++ ) graphics[i].opacity = 0;
								//CF.setProperties(graphics, 0, 2, CF.AnimationCurveLinear, function(js) {
									// change the opacity of the no media found image
									//CF.setProperties({"s"+self.joins.no_media_found, opacity: 1}, 0, 2);
								//});


								consolelog("JoinChangeEvent(l1): media loading timeout expired...");
							}, 30 * 1000); // 30 secs
						}
	/*
						var loadingIntervalID = setInterval(function() {
							consolelog("!!self.XBMC.mediaList[self.XBMC.currentList.type] = " + !!self.XBMC.mediaList[self.XBMC.currentList.type]);
							if ( self.XBMC.mediaList[self.XBMC.currentList.type] ) {

								// stop the loading timeout
								clearTimeout(loadingTimeoutID);
								delete loadingTimeoutID;

								// stop the loading interval
								clearInterval(loadingIntervalID);
								delete loadingIntervalID;

								// hide the loading graphics
								//for ( i = 0; i < graphics.length; i++ ) graphics[i].opacity = 0;
								//CF.setProperties(graphics, 0, 2, CF.AnimationCurveLinear, function(js) {

									// create the list
									consolelog("Adding the mediaList[currentList] array to the media list join");
									CF.listAdd("l"+self.joins.mediaList, self.XBMC.mediaList[self.XBMC.currentList.type]);

								//});

							}

						}, 2000);
*/
						// show the loading graphics
						/*
						for ( i = 0; i < graphics.length; i++ ) graphics[i].opacity = 1;
						CF.setProperties(graphics, 0, 2, CF.AnimationCurveLinear, function() {
								// animate the loading graphic
								var animate = function() {
									CF.setProperties({join: "s"+self.joins.media_loading_progress, x: -313}, 0.25, 0, CF.AnimationCurveLinear, function(js) {
										if (loadingTimeoutID) {
											CF.setProperties({join: js, x: 313}, 0, 2, CF.AniamtionCurveLinear, function(js) {
												animate();
											});
										}
									});
								};
								animate();
						});
						*/
					} else {
						// list created
						consolelog("JoinChangeEvent(l1): " + count + " " + self.XBMC.currentList.type + " have been added to the list");
						// stop the loading timeout
						consolelog("JoinChangeEvent(l1): clearing the media loading timeout");
						clearTimeout(loadingTimeoutID);
						delete loadingTimeoutID;

						// stop the loading interval
						//clearInterval(loadingIntervalID);
						//delete loadingIntervalID;

						// hide the loading graphics
						//for ( i = 0; i < graphics.length; i++ ) graphics[i].opacity = 0;
						//CF.setProperties(graphics, 0, 2, CF.AnimationCurveLinear, function(js) {
						//});
						// change the opacity of the no media found image
						//CF.setProperties({"s"+self.joins.no_media_found, opacity: 0}, 0, 2);



						//CF.flipToPage("XBMC_Wall_List"); // TEMPORARY - remove when not reqd
						//autoFlipToWall = false; // reset // TEMPORARY - remove when not reqd
					}
				});

				break;
		}
	}

	function onConnectionChange(system, connected, remote) {
		// On connected==true, the remote is a string
		// for example: "192.168.0.16:5050"
		// When getting initial status, if the system is not connected, remote is null.
		if (connected) {
			consolelog("System " + system + " connected with " + remote);
			CF.setJoins([
				{join: "d"+self.joins.diagnostics, value: 1},
				{join: "d"+self.joins.mediaList, value: 0},
			]);

		} else {
			if (remote === null) consolelog("Initial status: system " + system + " is not connected.");
			else consolelog("System " + system + " disconnected from " + remote);
		}
	}

	function setMediaListTitle(m) {
		if (!m) m = self.XBMC.currentList;

		title = m["type"][0].toUpperCase() + m["type"].substr(1);
		consolelog("Setting the media list title serial join to \"" + title + "\" using setMediaListTitle(m)");
		CF.setJoins([
			{join: "s"+self.joins.mediaList, value: title, tokens: m }
		]);

	}


	// function for decoding string with accents
	function decode_utf8(string) {
		return decodeURIComponent(escape(string));
	};

	function cleanImage(img) {
		try {
			if (img == "") return img;
			else return self.XBMC.GetURL("HTTP") + "image/" + encodeURIComponent(img);
		} catch (e) {
			console.log ("Exception caught in cleanImage() - " + e);
			return img;
		}
	};

	function consolelog(msg) {
		if (CF.debug) console.log("XBMC_GUI: " + msg);
	}

	function CFlog(msg) {
		if (CF.debug) CF.log("XBMC_GUI: " + msg);
	}

	// --- Initialisation --- //
	return self;
}